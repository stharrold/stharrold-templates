---
type: directory-documentation
directory: .claude/skills/bmad-planner
title: Bmad Planner
sibling_claude: CLAUDE.md
parent: null
children:
  - ARCHIVED/README.md
---

# Bmad Planner

## Overview

Documentation for bmad-planner

## Contents

[Describe the contents of this directory]

## Structure

[Explain the organization and key files]

## Usage

[How to use the resources in this directory]

## Related Documentation

- **[CLAUDE.md](CLAUDE.md)** - Context for Claude Code
