---
type: gemini-context
directory: specs/005-implement-workflow-all/contracts
purpose: API contracts and interface definitions for this feature.
parent: ../GEMINI.md
sibling_readme: null
children:
  []
---

# Gemini Code Context: contracts

## Purpose

API contracts and interface definitions for this feature.

## Contents

- `all.md` - Documentation

## Related

- **Parent**: [005-implement-workflow-all](../GEMINI.md)
