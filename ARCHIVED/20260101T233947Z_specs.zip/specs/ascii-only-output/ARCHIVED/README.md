# ARCHIVED

Archive directory for deprecated or superseded specification files related to the ascii-only-output feature.

## Contents

Currently empty.

## Purpose

When specification files are updated or replaced, the old versions are archived here with timestamps for traceability.
