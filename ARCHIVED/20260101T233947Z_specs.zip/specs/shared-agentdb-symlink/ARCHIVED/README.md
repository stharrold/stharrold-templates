# Archived: specs/shared-agentdb-symlink

Deprecated specification files are stored here.
