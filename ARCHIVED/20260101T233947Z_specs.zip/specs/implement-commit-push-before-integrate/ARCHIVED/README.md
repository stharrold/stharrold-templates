# Archived: specs/implement-commit-push-before-integrate

Deprecated specification files are stored here.
