---
type: gemini-context
directory: specs/003-rename-slash-command/contracts
purpose: API contracts and interface definitions for this feature.
parent: ../GEMINI.md
sibling_readme: null
children:
  []
---

# Gemini Code Context: contracts

## Purpose

API contracts and interface definitions for this feature.

## Contents

*(Empty or contains only hidden files)*

## Related

- **Parent**: [003-rename-slash-command](../GEMINI.md)
