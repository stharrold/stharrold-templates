---
type: gemini-context
directory: specs/008-workflow-skill-integration/contracts
purpose: API contracts and interface definitions for this feature.
parent: ../GEMINI.md
sibling_readme: null
children:
  []
---

# Gemini Code Context: contracts

## Purpose

API contracts and interface definitions for this feature.

## Contents

- `slash-commands.md` - Documentation
- `state-tracking.md` - Documentation

## Related

- **Parent**: [008-workflow-skill-integration](../GEMINI.md)
