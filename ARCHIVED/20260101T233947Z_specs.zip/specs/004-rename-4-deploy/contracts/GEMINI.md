---
type: gemini-context
directory: specs/004-rename-4-deploy/contracts
purpose: API contracts and interface definitions for this feature.
parent: ../GEMINI.md
sibling_readme: null
children:
  []
---

# Gemini Code Context: contracts

## Purpose

API contracts and interface definitions for this feature.

## Contents

- `4_integrate.md` - Documentation
- `5_release.md` - Documentation
- `6_backmerge.md` - Documentation

## Related

- **Parent**: [004-rename-4-deploy](../GEMINI.md)
