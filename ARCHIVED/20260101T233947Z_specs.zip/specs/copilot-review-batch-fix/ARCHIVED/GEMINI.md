---
type: gemini-context
directory: specs/copilot-review-batch-fix/ARCHIVED
purpose: Archived specifications and deprecated files
parent: ../GEMINI.md
sibling_readme: README.md
children: []
---

# Gemini Code Context: specs/copilot-review-batch-fix/ARCHIVED

Archived specifications and deprecated files.
