---
type: directory-documentation
directory: .gemini/skills/workflow-utilities/ARCHIVED
title: Archived Files
sibling_gemini: GEMINI.md
parent: ../README.md
children: []
---

# Archived Files

## Overview

Archive of deprecated files that are no longer in active use.

## Contents

[Describe the contents of this directory]

## Structure

[Explain the organization and key files]

## Usage

[How to use the resources in this directory]

## Related Documentation

- **[GEMINI.md](GEMINI.md)** - Context for Gemini Code
- **[../README.md](../README.md)** - Parent directory documentation
