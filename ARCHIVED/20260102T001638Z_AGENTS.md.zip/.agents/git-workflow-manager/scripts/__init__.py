#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2025 stharrold
# SPDX-License-Identifier: Apache-2.0
"""Git Workflow Manager skill scripts package."""

__version__ = "5.0.0"
