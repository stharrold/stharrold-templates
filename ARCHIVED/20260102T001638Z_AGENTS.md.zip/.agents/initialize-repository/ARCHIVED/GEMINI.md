---
type: gemini-context
directory: .gemini/skills/initialize-repository/ARCHIVED
purpose: Archive of deprecated files from initialize-repository
parent: ../GEMINI.md
sibling_readme: README.md
children: []
related_skills:
  - workflow-utilities
---

# Gemini Code Context: initialize-repository/ARCHIVED

Archived files from initialize-repository skill

## Purpose

This directory contains deprecated files from the initialize-repository skill that have been superseded by newer versions but are preserved for reference.

## Related Documentation

- **[README.md](README.md)** - Human-readable documentation for archived files
- **[../GEMINI.md](../GEMINI.md)** - Current initialize-repository context
