---
type: gemini-context
directory: .gemini/skills/agentdb-state-manager/ARCHIVED
purpose: Archive of deprecated files from agentdb-state-manager
parent: ../GEMINI.md
sibling_readme: README.md
children: []
related_skills:
  - workflow-utilities
---

# Gemini Code Context: agentdb-state-manager/ARCHIVED

Archived files from agentdb-state-manager skill

## Purpose

This directory contains deprecated files from the agentdb-state-manager skill that have
been superseded by newer versions but are preserved for reference.

## Related Documentation

- **[README.md](README.md)** - Human-readable documentation for archived files
- **[../GEMINI.md](../GEMINI.md)** - Current agentdb-state-manager context
