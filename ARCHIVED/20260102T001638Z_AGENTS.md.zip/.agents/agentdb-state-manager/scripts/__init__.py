#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2025 stharrold
# SPDX-License-Identifier: Apache-2.0
"""AgentDB State Manager skill scripts package."""

__version__ = "1.0.0"
