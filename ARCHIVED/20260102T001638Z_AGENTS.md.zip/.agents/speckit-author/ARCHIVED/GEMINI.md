---
type: gemini-context
directory: .gemini/skills/speckit-author/ARCHIVED
purpose: Archive of deprecated files from speckit-author
parent: ../GEMINI.md
sibling_readme: README.md
children: []
related_skills:
  - workflow-utilities
---

# Gemini Code Context: Archived Content

## Purpose

Archive of deprecated files from speckit-author

## Directory Structure

[Describe the organization of files in this directory]

## Files in This Directory

[List key files and their purposes]

## Usage

[How to work with code/content in this directory]


## Related Documentation

- **[README.md](README.md)** - Human-readable documentation for this directory
- **[../GEMINI.md](../GEMINI.md)** - Parent directory: speckit-author

## Related Skills

- workflow-orchestrator
- workflow-utilities
