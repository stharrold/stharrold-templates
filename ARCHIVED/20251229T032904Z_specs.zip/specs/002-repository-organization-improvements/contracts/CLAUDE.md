---
type: claude-context
directory: specs/002-repository-organization-improvements/contracts
purpose: API contracts and interface definitions for this feature.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: contracts

## Purpose

API contracts and interface definitions for this feature.

## Contents

- `validation-contract.md` - Documentation

## Related

- **Parent**: [002-repository-organization-improvements](../CLAUDE.md)
