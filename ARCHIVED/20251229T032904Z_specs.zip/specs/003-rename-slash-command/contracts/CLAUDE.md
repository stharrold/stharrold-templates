---
type: claude-context
directory: specs/003-rename-slash-command/contracts
purpose: API contracts and interface definitions for this feature.
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: contracts

## Purpose

API contracts and interface definitions for this feature.

## Contents

*(Empty or contains only hidden files)*

## Related

- **Parent**: [003-rename-slash-command](../CLAUDE.md)
