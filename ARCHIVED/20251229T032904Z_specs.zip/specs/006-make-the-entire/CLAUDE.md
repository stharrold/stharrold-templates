---
type: claude-context
directory: specs/006-make-the-entire
purpose: Feature specification for 006 Make The Entire.
parent: ../CLAUDE.md
sibling_readme: null
children:
  - contracts/CLAUDE.md
---

# Claude Code Context: 006-make-the-entire

## Purpose

Feature specification for 006 Make The Entire.

## Contents

- `contracts/` - Subdirectory
- `data-model.md` - Documentation
- `plan.md` - Documentation
- `quickstart.md` - Documentation
- `research.md` - Documentation

## Related

- **Parent**: [specs](../CLAUDE.md)
- **contracts**: [contracts/CLAUDE.md](contracts/CLAUDE.md)
