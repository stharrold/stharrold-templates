---
type: claude-context
directory: specs/ascii-only-output/ARCHIVED
purpose: Archived files for ascii-only-output specification
parent: ../CLAUDE.md
sibling_readme: README.md
children: []
---

# Claude Code Context: ARCHIVED

## Purpose

Archive directory for deprecated or superseded specification files.

## Contents

Currently empty.

## Related

- **Parent**: [ascii-only-output](../CLAUDE.md)
