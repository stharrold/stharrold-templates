---
type: claude-context
directory: specs/004-rename-4-deploy
purpose: Feature specification for 004 Rename 4 Deploy.
parent: ../CLAUDE.md
sibling_readme: null
children:
  - contracts/CLAUDE.md
---

# Claude Code Context: 004-rename-4-deploy

## Purpose

Feature specification for 004 Rename 4 Deploy.

## Contents

- `contracts/` - Subdirectory
- `data-model.md` - Documentation
- `plan.md` - Documentation
- `quickstart.md` - Documentation
- `research.md` - Documentation

## Related

- **Parent**: [specs](../CLAUDE.md)
- **contracts**: [contracts/CLAUDE.md](contracts/CLAUDE.md)
