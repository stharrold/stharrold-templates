# Archived: specs/copilot-review-batch-fix

Deprecated specification files are stored here.
