---
type: claude-context
directory: specs/copilot-review-batch-fix/ARCHIVED
purpose: Archived specifications and deprecated files
parent: ../CLAUDE.md
sibling_readme: README.md
children: []
---

# Claude Code Context: specs/copilot-review-batch-fix/ARCHIVED

Archived specifications and deprecated files.
