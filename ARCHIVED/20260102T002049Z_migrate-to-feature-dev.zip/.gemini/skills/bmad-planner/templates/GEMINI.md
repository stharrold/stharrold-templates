---
type: gemini-context
directory: .gemini/skills/bmad-planner/templates
purpose: Markdown and code templates for this skill.
parent: ../GEMINI.md
sibling_readme: null
children:
  []
---

# Gemini Code Context: templates

## Purpose

Markdown and code templates for this skill.

## Contents

*(Empty or contains only hidden files)*

## Related

- **Parent**: [bmad-planner](../GEMINI.md)
