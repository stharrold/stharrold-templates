---
type: directory-documentation
directory: .gemini/skills/bmad-planner
title: Bmad Planner
sibling_gemini: GEMINI.md
parent: null
children:
  - ARCHIVED/README.md
---

# Bmad Planner

## Overview

Documentation for bmad-planner

## Contents

[Describe the contents of this directory]

## Structure

[Explain the organization and key files]

## Usage

[How to use the resources in this directory]

## Related Documentation

- **[GEMINI.md](GEMINI.md)** - Context for Gemini Code
