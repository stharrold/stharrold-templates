"""
Workflow utilities: Archive management, directory structure validation, version checking.
"""
