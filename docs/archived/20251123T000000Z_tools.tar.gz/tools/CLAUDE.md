---
type: claude-context
directory: tools
purpose: Standalone utility scripts (deprecated - use .claude/skills/ instead).
parent: ../CLAUDE.md
sibling_readme: README.md
children:
  - git-helpers/CLAUDE.md
  - workflow-utilities/CLAUDE.md
---

# Claude Code Context: tools

## Purpose

Standalone utility scripts (deprecated - use .claude/skills/ instead).

## Contents

- `README.md` - Documentation
- `git-helpers/` - Subdirectory
- `workflow-utilities/` - Subdirectory
- `__init__.py` - Python script

## Related

- **Parent**: [stharrold-templates](../CLAUDE.md)
- **README**: [README.md](README.md)
- **git-helpers**: [git-helpers/CLAUDE.md](git-helpers/CLAUDE.md)
- **workflow-utilities**: [workflow-utilities/CLAUDE.md](workflow-utilities/CLAUDE.md)
