---
type: claude-context
directory: tools/git-helpers
purpose: Git workflow helpers (deprecated - use git-workflow-manager skill).
parent: ../CLAUDE.md
sibling_readme: null
children:
  []
---

# Claude Code Context: git-helpers

## Purpose

Git workflow helpers (deprecated - use git-workflow-manager skill).

## Contents

- `__init__.py` - Python script
- `create_worktree.py` - Python script
- `semantic_version.py` - Python script

## Related

- **Parent**: [tools](../CLAUDE.md)
