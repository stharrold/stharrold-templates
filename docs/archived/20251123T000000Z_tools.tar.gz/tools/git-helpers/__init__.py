"""
Git helpers: Semantic versioning, worktree management.
"""
