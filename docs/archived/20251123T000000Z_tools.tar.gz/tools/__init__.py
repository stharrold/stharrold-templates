"""
Workflow tools package for stharrold-templates.

Selective integration of german workflow system (v5.3.0).
"""

__version__ = '5.3.0'
